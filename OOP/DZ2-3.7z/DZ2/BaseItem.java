package OOP.DZ2;

/**
 * базовый класс предметов
 */
abstract class BaseItem {
    String description;
}