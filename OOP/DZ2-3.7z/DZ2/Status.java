package OOP.DZ2;

enum Status {
    sleep,	//спит
    awake, 	//бодрствует
    angry, 	//злится
    hungry,	//голодный
    walks	//гуляет
}
