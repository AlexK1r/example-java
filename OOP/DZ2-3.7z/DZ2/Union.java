package OOP.DZ2;

enum Union {
        man,
        woman
    }

