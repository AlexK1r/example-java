package OOP.DZ1;

/**
 * Родственные отношения,  parent - родитель,  children - ребенок
 */
enum Relation {
    parent,
    partner,    
    children
}
