package OOP.DZ1;

enum Union {
    man, 
    woman, 
    none
}