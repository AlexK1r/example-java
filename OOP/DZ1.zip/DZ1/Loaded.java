package OOP.DZ1;

public interface Loaded<T> {
    T load();
}
