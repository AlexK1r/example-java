package OOP.DZ1;

public interface Saved<T> {
    void Save(T t);
}
